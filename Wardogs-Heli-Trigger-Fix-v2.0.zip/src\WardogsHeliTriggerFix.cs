/*
 * ============================================================================
 * Project:   WARDOGS Helicopter Analog Trigger Fix (Open Source Utility)
 * File:      WardogsHeliTriggerFix.cs
 * License:   MIT License
 * 
 * Technical Summary:
 * ------------------
 * In Wardogs (Season 2+), the helicopter flight controller (BHHeli_Core /
 * BHRotaryVehiclePawn) routes standard Gamepad trigger inputs (LT / RT)
 * through digital button events (PressCollectiveUp / ReleaseCollectiveUp and
 * PressCollectiveDown / ReleaseCollectiveDown) when bUseHOTASHelicopters=False.
 * As a result, pressing an analog trigger past ~1-2mm immediately commands
 * 100% collective rather than proportional 0-100% thrust.
 *
 * However, BHHeli_Core applies an internal first-order low-pass smoothing
 * filter (LagFilter / BHInterpolatedRotaryMovementControlAssistCondition)
 * to collective state transitions.
 *
 * How This Tool Solves the Problem:
 * ---------------------------------
 * 1. High-Frequency PWM Modulator (500 Hz Polling / Adjustable 15-60 Hz Carrier):
 *    Reads the raw 8-bit analog trigger values (0..255) directly from XInput,
 *    applies configurable inner/outer deadzones and an exponential response
 *    curve, and modulates hardware-level keyboard scancodes (SendInput) with a
 *    duty cycle proportional to trigger travel. The game's internal LagFilter
 *    integrates the pulse train into a smooth, proportional collective level
 *    (e.g., 50% trigger depression = 50% duty cycle = ~50% collective hover).
 *
 * 2. Universal GameUserSettings.ini Patcher (Diff-Safe INI Parser):
 *    Automatically locates %LOCALAPPDATA%\Wardogs\Saved\Config\WindowsClient\
 *    GameUserSettings.ini on any Windows PC (with manual browse fallback),
 *    creates a safe backup, and either:
 *      - Patch A (PWM Threshold Guard): Sets Left/RightTriggerMinMultiplier=95.0
 *        so the native binary trigger does not fire at 1-2mm, allowing the PWM
 *        modulator to control 0-95% travel seamlessly while 95-100% engages full
 *        hardware lock.
 *      - Patch B (Native DirectInput Z-Axis HOTAS): Enables bUseHOTASHelicopters
 *        and the hidden bCollectiveSelfCentering=True flag so Wardogs reads
 *        DirectInput Axis 2 (combined LT/RT Z-Axis) via InputCollectiveAbsolute.
 * ============================================================================
 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace WardogsHeliTriggerFix
{
    // ========================================================================
    // Theme Palette (Tactical Avionics / MFD Instrument Aesthetic)
    // ========================================================================
    internal static class AvionicsTheme
    {
        public static readonly Color BgChassis       = Color.FromArgb(17, 19, 17);   // #111311 Matte Charcoal-Olive
        public static readonly Color BgPanel         = Color.FromArgb(24, 27, 24);   // #181B18 Instrument Surface
        public static readonly Color BgInput         = Color.FromArgb(13, 15, 13);   // #0D0F0D Recessed Gauge Well
        public static readonly Color BorderSubtle    = Color.FromArgb(44, 50, 44);   // #2C322C Bevel Line
        public static readonly Color BorderAccent    = Color.FromArgb(82, 94, 78);   // #525E4E Tactical Reticle
        public static readonly Color TextPrimary     = Color.FromArgb(226, 230, 222);// #E2E6DE Crisp Off-White
        public static readonly Color TextSecondary   = Color.FromArgb(142, 152, 138);// #8E988A Muted Technical Label
        public static readonly Color TextDim         = Color.FromArgb(92, 100, 90);  // #5C645A Grid / Unit Label
        public static readonly Color AmberPrimary    = Color.FromArgb(216, 142, 44); // #D88E2C Avionics Amber
        public static readonly Color AmberBright     = Color.FromArgb(240, 178, 72); // #F0B248 Highlight Amber
        public static readonly Color PhosphorGreen   = Color.FromArgb(112, 186, 88); // #70BA58 MFD Active Green
        public static readonly Color DescentRust     = Color.FromArgb(204, 96, 56);  // #CC6038 Descent / Warning Orange
        public static readonly Color DangerRed       = Color.FromArgb(180, 62, 58);  // #B43E3A Alert / Reset
    }

    // ========================================================================
    // Custom Double-Buffered Avionics Bar Gauge Control
    // ========================================================================
    internal sealed class AvionicsBarGauge : Control
    {
        public float ValueNormalized { get; set; }     // 0.0 .. 1.0
        public float SecondaryNormalized { get; set; } // 0.0 .. 1.0 (e.g. post-curve output)
        public float DeadzoneInnerNorm { get; set; }   // 0.0 .. 1.0
        public float DeadzoneOuterNorm { get; set; }   // 0.0 .. 1.0
        public Color FillColor { get; set; }
        public string LeftText { get; set; }
        public string RightText { get; set; }

        public AvionicsBarGauge()
        {
            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw, true);
            this.Height = 24;
            this.FillColor = AvionicsTheme.AmberPrimary;
            this.DeadzoneInnerNorm = 0.03f;
            this.DeadzoneOuterNorm = 0.97f;
            this.LeftText = "";
            this.RightText = "0%";
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.None;
            Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);

            using (SolidBrush bgBrush = new SolidBrush(AvionicsTheme.BgInput))
                g.FillRectangle(bgBrush, rect);

            // Draw deadzone shading
            int dzLeftW = (int)Math.Round(rect.Width * DeadzoneInnerNorm);
            int dzRightX = (int)Math.Round(rect.Width * DeadzoneOuterNorm);
            using (SolidBrush dzBrush = new SolidBrush(Color.FromArgb(28, 180, 62, 58)))
            {
                if (dzLeftW > 1)
                    g.FillRectangle(dzBrush, 1, 1, dzLeftW, rect.Height - 2);
                if (dzRightX < rect.Width - 1)
                    g.FillRectangle(dzBrush, dzRightX, 1, rect.Width - dzRightX - 1, rect.Height - 2);
            }

            // Primary raw fill (top 65% of bar)
            float clamped = Math.Max(0f, Math.Min(1f, ValueNormalized));
            int fillW = (int)Math.Round((rect.Width - 2) * clamped);
            if (fillW > 0)
            {
                using (SolidBrush fillBrush = new SolidBrush( Color.FromArgb(185, FillColor) ))
                    g.FillRectangle(fillBrush, 1, 1, fillW, rect.Height - 6);
            }

            // Secondary curved output bar (bottom 4px strip)
            float clampedSec = Math.Max(0f, Math.Min(1f, SecondaryNormalized));
            int secW = (int)Math.Round((rect.Width - 2) * clampedSec);
            if (secW > 0)
            {
                using (SolidBrush secBrush = new SolidBrush(AvionicsTheme.PhosphorGreen))
                    g.FillRectangle(secBrush, 1, rect.Height - 5, secW, 4);
            }

            // 10% scale tick marks
            using (Pen tickPen = new Pen(Color.FromArgb(70, 90, 98, 88), 1f))
            {
                for (int i = 1; i < 10; i++)
                {
                    int tx = (rect.Width * i) / 10;
                    int tickH = (i == 5) ? 7 : 4;
                    g.DrawLine(tickPen, tx, 1, tx, 1 + tickH);
                }
            }

            // Border
            using (Pen borderPen = new Pen(AvionicsTheme.BorderSubtle, 1f))
                g.DrawRectangle(borderPen, rect);

            // Overlay telemetry text
            using (Font f = new Font("Consolas", 8.5f, FontStyle.Bold))
            {
                if (!string.IsNullOrEmpty(LeftText))
                {
                    TextRenderer.DrawText(g, LeftText, f, new Rectangle(6, 0, rect.Width / 2, rect.Height),
                        AvionicsTheme.TextSecondary, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
                }
                if (!string.IsNullOrEmpty(RightText))
                {
                    TextRenderer.DrawText(g, RightText, f, new Rectangle(rect.Width / 2, 0, rect.Width / 2 - 6, rect.Height),
                        AvionicsTheme.TextPrimary, TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
                }
            }
        }
    }

    // ========================================================================
    // Custom Center-Zero Collective Output & LagFilter Gauge
    // ========================================================================
    internal sealed class CollectiveCenterGauge : Control
    {
        public float CollectiveValue { get; set; } // -1.0 (Descent) .. +1.0 (Climb)
        public bool PulseHigh { get; set; }
        public int PulseDirection { get; set; }    // -1 = Down, 0 = Idle, +1 = Up

        public CollectiveCenterGauge()
        {
            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw, true);
            this.Height = 28;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);

            using (SolidBrush bg = new SolidBrush(AvionicsTheme.BgInput))
                g.FillRectangle(bg, rect);

            int midX = rect.Width / 2;
            float clamped = Math.Max(-1f, Math.Min(1f, CollectiveValue));

            if (clamped > 0.005f)
            {
                int w = (int)Math.Round((rect.Width / 2 - 2) * clamped);
                using (SolidBrush b = new SolidBrush(Color.FromArgb(190, AvionicsTheme.PhosphorGreen)))
                    g.FillRectangle(b, midX, 2, w, rect.Height - 4);
            }
            else if (clamped < -0.005f)
            {
                int w = (int)Math.Round((rect.Width / 2 - 2) * (-clamped));
                using (SolidBrush b = new SolidBrush(Color.FromArgb(190, AvionicsTheme.DescentRust)))
                    g.FillRectangle(b, midX - w, 2, w, rect.Height - 4);
            }

            // Tick marks
            using (Pen tickPen = new Pen(Color.FromArgb(80, 90, 98, 88), 1f))
            {
                for (int i = 1; i < 10; i++)
                {
                    int tx = (rect.Width * i) / 10;
                    g.DrawLine(tickPen, tx, 1, tx, 5);
                    g.DrawLine(tickPen, tx, rect.Height - 5, tx, rect.Height - 1);
                }
            }

            // Center hover line
            using (Pen centerPen = new Pen(AvionicsTheme.AmberBright, 2f))
                g.DrawLine(centerPen, midX, 1, midX, rect.Height - 1);

            // Outer border
            using (Pen borderPen = new Pen(AvionicsTheme.BorderSubtle, 1f))
                g.DrawRectangle(borderPen, rect);

            int pct = (int)Math.Round(clamped * 100f);
            string status = pct == 0
                ? "0% [NEUTRAL HOVER]"
                : (pct > 0 ? string.Format("+{0}% [CLIMB COLLECTIVE]", pct) : string.Format("{0}% [DESCENT COLLECTIVE]", pct));

            using (Font f = new Font("Consolas", 9f, FontStyle.Bold))
            {
                TextRenderer.DrawText(g, "DESCENT (-)", f, new Rectangle(8, 0, 110, rect.Height),
                    AvionicsTheme.TextDim, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
                TextRenderer.DrawText(g, "CLIMB (+)", f, new Rectangle(rect.Width - 118, 0, 110, rect.Height),
                    AvionicsTheme.TextDim, TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
                TextRenderer.DrawText(g, status, f, rect,
                    AvionicsTheme.TextPrimary, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            }
        }
    }

    // ========================================================================
    // Live Interactive Response Curve Visualizer (Input vs PWM Duty Cycle)
    // ========================================================================
    internal sealed class ResponseCurveCanvas : Control
    {
        public float Expo { get; set; }
        public float MaxScale { get; set; }
        public float DeadzoneInner { get; set; } // 0..1
        public float DeadzoneOuter { get; set; } // 0..1
        public float LiveInputX { get; set; }    // 0..1
        public float LiveOutputY { get; set; }   // 0..1

        public ResponseCurveCanvas()
        {
            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw, true);
            this.Expo = 1.6f;
            this.MaxScale = 1.0f;
            this.DeadzoneInner = 0.03f;
            this.DeadzoneOuter = 0.97f;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int pad = 22;
            Rectangle plot = new Rectangle(pad, 10, this.Width - pad - 10, this.Height - pad - 10);

            using (SolidBrush bg = new SolidBrush(AvionicsTheme.BgInput))
                g.FillRectangle(bg, plot);

            // Grid lines (25%, 50%, 75%)
            using (Pen gridPen = new Pen(Color.FromArgb(40, 120, 130, 115), 1f))
            {
                for (int i = 1; i <= 3; i++)
                {
                    int gx = plot.Left + (plot.Width * i) / 4;
                    int gy = plot.Top + (plot.Height * i) / 4;
                    g.DrawLine(gridPen, gx, plot.Top, gx, plot.Bottom);
                    g.DrawLine(gridPen, plot.Left, gy, plot.Right, gy);
                }
            }

            // Linear reference diagonal
            using (Pen diagPen = new Pen(Color.FromArgb(55, 160, 165, 155), 1f))
            {
                diagPen.DashStyle = DashStyle.Dot;
                g.DrawLine(diagPen, plot.Left, plot.Bottom, plot.Right, plot.Top);
            }

            // Compute & draw response curve
            List<PointF> pts = new List<PointF>(plot.Width + 1);
            for (int px = 0; px <= plot.Width; px++)
            {
                float x = (float)px / Math.Max(1, plot.Width);
                float y = EvaluateCurve(x);
                float sx = plot.Left + x * plot.Width;
                float sy = plot.Bottom - y * plot.Height;
                pts.Add(new PointF(sx, sy));
            }

            if (pts.Count > 1)
            {
                using (Pen curvePen = new Pen(AvionicsTheme.AmberPrimary, 2.0f))
                    g.DrawLines(curvePen, pts.ToArray());
            }

            // Draw live input operating point crosshair
            float lx = plot.Left + Math.Max(0f, Math.Min(1f, LiveInputX)) * plot.Width;
            float ly = plot.Bottom - Math.Max(0f, Math.Min(1f, LiveOutputY)) * plot.Height;

            using (Pen crossPen = new Pen(Color.FromArgb(120, AvionicsTheme.PhosphorGreen), 1f))
            {
                g.DrawLine(crossPen, lx, plot.Top, lx, plot.Bottom);
                g.DrawLine(crossPen, plot.Left, ly, plot.Right, ly);
            }
            using (SolidBrush dotBrush = new SolidBrush(AvionicsTheme.PhosphorGreen))
            {
                g.FillEllipse(dotBrush, lx - 4f, ly - 4f, 8f, 8f);
            }

            g.SmoothingMode = SmoothingMode.None;
            using (Pen borderPen = new Pen(AvionicsTheme.BorderSubtle, 1f))
                g.DrawRectangle(borderPen, plot);

            using (Font f = new Font("Consolas", 7.5f, FontStyle.Regular))
            {
                TextRenderer.DrawText(g, "100%", f, new Point(0, plot.Top - 2), AvionicsTheme.TextDim);
                TextRenderer.DrawText(g, "0%", f, new Point(6, plot.Bottom - 10), AvionicsTheme.TextDim);
                TextRenderer.DrawText(g, "IN -> OUT CURVE", f,
                    new Rectangle(plot.Left, plot.Bottom + 2, plot.Width, 18),
                    AvionicsTheme.TextSecondary, TextFormatFlags.HorizontalCenter);
            }
        }

        private float EvaluateCurve(float rawX)
        {
            if (rawX <= DeadzoneInner) return 0f;
            if (rawX >= DeadzoneOuter) return MaxScale;
            float norm = (rawX - DeadzoneInner) / Math.Max(0.001f, DeadzoneOuter - DeadzoneInner);
            float curved = (float)Math.Pow(norm, Expo) * MaxScale;
            return Math.Max(0f, Math.Min(1f, curved));
        }
    }

    // ========================================================================
    // Custom Tactical Section Panel with Corner Reticle Accents
    // ========================================================================
    internal sealed class TacticalPanel : Panel
    {
        public string SectionTitle { get; set; }
        public string SectionSubtitle { get; set; }

        public TacticalPanel(string title, string subtitle = "")
        {
            this.SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw, true);
            this.SectionTitle = title;
            this.SectionSubtitle = subtitle;
            this.BackColor = AvionicsTheme.BgPanel;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);

            // Header bar background
            using (SolidBrush hdrBrush = new SolidBrush(Color.FromArgb(20, 22, 20)))
                g.FillRectangle(hdrBrush, 1, 1, rect.Width - 1, 26);

            using (Pen sepPen = new Pen(AvionicsTheme.BorderSubtle, 1f))
            {
                g.DrawLine(sepPen, 1, 27, rect.Width - 1, 27);
                g.DrawRectangle(sepPen, rect);
            }

            // Left amber accent bar in header
            using (SolidBrush accent = new SolidBrush(AvionicsTheme.AmberPrimary))
                g.FillRectangle(accent, 1, 1, 3, 26);

            // Corner tactical ticks
            using (Pen cornerPen = new Pen(AvionicsTheme.BorderAccent, 1f))
            {
                int c = 6;
                g.DrawLine(cornerPen, rect.Right - c, 0, rect.Right, 0);
                g.DrawLine(cornerPen, rect.Right, 0, rect.Right, c);
                g.DrawLine(cornerPen, 0, rect.Bottom - c, 0, rect.Bottom);
                g.DrawLine(cornerPen, 0, rect.Bottom, c, rect.Bottom);
                g.DrawLine(cornerPen, rect.Right - c, rect.Bottom, rect.Right, rect.Bottom);
                g.DrawLine(cornerPen, rect.Right, rect.Bottom - c, rect.Right, rect.Bottom);
            }

            using (Font fTitle = new Font("Consolas", 9.0f, FontStyle.Bold))
            {
                TextRenderer.DrawText(g, SectionTitle, fTitle, new Rectangle(10, 0, rect.Width - 20, 27),
                    AvionicsTheme.AmberBright, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            }

            if (!string.IsNullOrEmpty(SectionSubtitle))
            {
                using (Font fSub = new Font("Consolas", 8.0f, FontStyle.Regular))
                {
                    TextRenderer.DrawText(g, SectionSubtitle, fSub, new Rectangle(10, 0, rect.Width - 18, 27),
                        AvionicsTheme.TextDim, TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
                }
            }
        }
    }

    // ========================================================================
    // Main Application Form
    // ========================================================================
    public sealed class MainForm : Form
    {
        // --------------------------------------------------------------------
        // Native Win32 / XInput / Multimedia Timer P/Invoke Declarations
        // --------------------------------------------------------------------
        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();

        [StructLayout(LayoutKind.Sequential)]
        public struct XINPUT_GAMEPAD
        {
            public ushort wButtons;
            public byte bLeftTrigger;
            public byte bRightTrigger;
            public short sThumbLX;
            public short sThumbLY;
            public short sThumbRX;
            public short sThumbRY;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct XINPUT_STATE
        {
            public uint dwPacketNumber;
            public XINPUT_GAMEPAD Gamepad;
        }

        [DllImport("xinput1_4.dll", EntryPoint = "XInputGetState")]
        private static extern uint XInputGetState_14(uint dwUserIndex, out XINPUT_STATE pState);

        [DllImport("xinput1_3.dll", EntryPoint = "XInputGetState")]
        private static extern uint XInputGetState_13(uint dwUserIndex, out XINPUT_STATE pState);

        [DllImport("xinput9_1_0.dll", EntryPoint = "XInputGetState")]
        private static extern uint XInputGetState_910(uint dwUserIndex, out XINPUT_STATE pState);

        [DllImport("winmm.dll")]
        private static extern uint timeBeginPeriod(uint uPeriod);

        [DllImport("winmm.dll")]
        private static extern uint timeEndPeriod(uint uPeriod);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        [StructLayout(LayoutKind.Sequential)]
        private struct INPUT
        {
            public uint type;
            public InputUnion u;
        }

        [StructLayout(LayoutKind.Explicit)]
        private struct InputUnion
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
            [FieldOffset(0)] public KEYBDINPUT ki;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [DllImport("user32.dll")]
        private static extern uint MapVirtualKey(uint uCode, uint uMapType);

        private const uint INPUT_KEYBOARD = 1;
        private const uint KEYEVENTF_SCANCODE = 0x0008;
        private const uint KEYEVENTF_KEYUP = 0x0002;
        private const uint KEYEVENTF_EXTENDEDKEY = 0x0001;

        private const ushort XINPUT_GAMEPAD_DPAD_UP = 0x0001;
        private const ushort XINPUT_GAMEPAD_LEFT_SHOULDER = 0x0100;
        private const ushort XINPUT_GAMEPAD_RIGHT_SHOULDER = 0x0200;

        // --------------------------------------------------------------------
        // Runtime Parameters (Thread-Safe Volatile State)
        // --------------------------------------------------------------------
        private volatile bool _running = true;
        private volatile bool _pwmEnabled = true;
        private volatile int _pwmFreqHz = 28;
        private volatile float _expoCurve = 1.6f;
        private volatile int _deadzoneInner = 8;    // 0..255 (~3%)
        private volatile int _deadzoneOuter = 247;  // 0..255 (~97%)
        private volatile float _maxPowerScale = 1.0f;
        private volatile ushort _vkCollectiveUp = 0x20;   // Default: SPACE
        private volatile ushort _vkCollectiveDown = 0xA2; // Default: Left Ctrl
        private volatile int _preferredControllerSlot = -1; // -1 = Auto-detect (0..3)

        // Live Telemetry State
        private volatile int _rawLT = 0;
        private volatile int _rawRT = 0;
        private volatile float _dutyUp = 0f;
        private volatile float _dutyDown = 0f;
        private volatile float _simulatedCollective = 0f;
        private volatile bool _pulseStateUp = false;
        private volatile bool _pulseStateDown = false;
        private volatile int _activeControllerIndex = -1;

        private bool _keyUpPressedByUs = false;
        private bool _keyDownPressedByUs = false;

        private Thread _workerThread;
        private System.Windows.Forms.Timer _uiTimer;

        // Paths
        private string _wardogsIniPath;
        private readonly string _localConfigPath;

        // UI Controls
        private Label _lblGamepadBadge;
        private Label _lblPwmStateBadge;
        private AvionicsBarGauge _gaugeLT;
        private AvionicsBarGauge _gaugeRT;
        private CollectiveCenterGauge _gaugeCollective;
        private ResponseCurveCanvas _curveCanvas;
        private Panel _pnlGateLamp;
        private Label _lblGateText;

        private CheckBox _chkPwmActive;
        private ComboBox _cmbKeyUp;
        private ComboBox _cmbKeyDown;
        private ComboBox _cmbControllerSlot;
        private TrackBar _trkFreq;
        private Label _lblFreqReadout;
        private TrackBar _trkExpo;
        private Label _lblExpoReadout;
        private TrackBar _trkDzInner;
        private Label _lblDzInnerReadout;
        private TrackBar _trkMaxScale;
        private Label _lblMaxScaleReadout;

        private TextBox _txtIniPath;
        private Label _lblIniStatus;
        private TextBox _txtLog;

        private struct KeyBindingItem
        {
            public readonly string Label;
            public readonly ushort VirtualKey;
            public KeyBindingItem(string label, ushort vk)
            {
                Label = label;
                VirtualKey = vk;
            }
            public override string ToString() { return Label; }
        }

        public MainForm()
        {
            _localConfigPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WardogsTriggerFix.cfg");
            _wardogsIniPath = AutoDetectWardogsIniPath();

            BuildTacticalInterface();
            LoadLocalConfiguration();
            RefreshIniPathDiagnostics();

            // Enable 1ms OS scheduler timer granularity for jitter-free PWM
            timeBeginPeriod(1);

            _workerThread = new Thread(PwmSamplingLoop)
            {
                Name = "WardogsPwmWorker",
                IsBackground = true,
                Priority = ThreadPriority.Highest
            };
            _workerThread.Start();

            _uiTimer = new System.Windows.Forms.Timer { Interval = 30 };
            _uiTimer.Tick += OnUiRefreshTick;
            _uiTimer.Start();

            AppendLog("SYSTEM READY // 500 Hz XInput Sampler & PWM Modulator initialized.");
            AppendLog("HOTKEYS      // Press [F8] or Gamepad [LB + RB + D-Pad UP] to toggle Heli-PWM in-game.");
        }

        // --------------------------------------------------------------------
        // Automatic Cross-Machine Path Discovery for Wardogs Config
        // --------------------------------------------------------------------
        private static string AutoDetectWardogsIniPath()
        {
            List<string> candidates = new List<string>();

            // 1. Standard %LOCALAPPDATA%\Wardogs\Saved\Config\WindowsClient\GameUserSettings.ini
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (!string.IsNullOrEmpty(localAppData))
            {
                candidates.Add(Path.Combine(localAppData, @"Wardogs\Saved\Config\WindowsClient\GameUserSettings.ini"));
                candidates.Add(Path.Combine(localAppData, @"Wardogs\Saved\Config\Windows\GameUserSettings.ini"));
                candidates.Add(Path.Combine(localAppData, @"WARDOGS Playtest\Saved\Config\WindowsClient\GameUserSettings.ini"));
            }

            // 2. Fallback via USERPROFILE\AppData\Local
            string userProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (!string.IsNullOrEmpty(userProfile))
            {
                candidates.Add(Path.Combine(userProfile, @"AppData\Local\Wardogs\Saved\Config\WindowsClient\GameUserSettings.ini"));
            }

            foreach (string path in candidates)
            {
                if (File.Exists(path))
                    return path;
            }

            // Return the canonical default path even if the game hasn't generated it yet
            return candidates.Count > 0 ? candidates[0] : @"GameUserSettings.ini";
        }

        // --------------------------------------------------------------------
        // Build Tactical Avionics UI
        // --------------------------------------------------------------------
        private void BuildTacticalInterface()
        {
            this.Text = "WARDOGS // HELICOPTER COLLECTIVE ANALOG TRIGGER INTERFACE [v2.0 OPEN SOURCE]";
            this.ClientSize = new Size(820, 740);
            this.MinimumSize = new Size(820, 740);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = AvionicsTheme.BgChassis;
            this.ForeColor = AvionicsTheme.TextPrimary;
            this.Font = new Font("Segoe UI", 9.0f, FontStyle.Regular);

            int margin = 12;
            int width = this.ClientSize.Width - margin * 2;
            int y = 10;

            // ================================================================
            // TOP STATUS HEADER BAR
            // ================================================================
            Panel topBar = new Panel
            {
                Location = new Point(margin, y),
                Size = new Size(width, 54),
                BackColor = AvionicsTheme.BgPanel
            };
            topBar.Paint += (s, e) =>
            {
                Rectangle r = new Rectangle(0, 0, topBar.Width - 1, topBar.Height - 1);
                using (Pen p = new Pen(AvionicsTheme.BorderSubtle)) e.Graphics.DrawRectangle(p, r);
                using (SolidBrush b = new SolidBrush(AvionicsTheme.AmberPrimary))
                    e.Graphics.FillRectangle(b, 0, 0, 4, topBar.Height);
            };

            Label lblHeaderTitle = new Label
            {
                Text = "UH-72 LAKOTA / LITTLEBIRD // COLLECTIVE TRIGGER PWM & HOTAS CONTROLLER",
                Font = new Font("Consolas", 10.5f, FontStyle.Bold),
                ForeColor = AvionicsTheme.AmberBright,
                Location = new Point(14, 7),
                AutoSize = true
            };
            Label lblHeaderSub = new Label
            {
                Text = "Restores full 0-255 proportional analog trigger authority over BHHeli_Core LagFilter without vJoy/Gremlin",
                Font = new Font("Segoe UI", 8.25f, FontStyle.Regular),
                ForeColor = AvionicsTheme.TextSecondary,
                Location = new Point(14, 28),
                AutoSize = true
            };

            _lblGamepadBadge = new Label
            {
                Text = "[XINPUT: SCANNING]",
                Font = new Font("Consolas", 8.5f, FontStyle.Bold),
                ForeColor = AvionicsTheme.AmberPrimary,
                BackColor = AvionicsTheme.BgInput,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(width - 330, 8),
                Size = new Size(155, 18)
            };
            _lblPwmStateBadge = new Label
            {
                Text = "[MODULATOR: ARMED]",
                Font = new Font("Consolas", 8.5f, FontStyle.Bold),
                ForeColor = AvionicsTheme.PhosphorGreen,
                BackColor = AvionicsTheme.BgInput,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(width - 168, 8),
                Size = new Size(158, 18)
            };

            topBar.Controls.Add(lblHeaderTitle);
            topBar.Controls.Add(lblHeaderSub);
            topBar.Controls.Add(_lblGamepadBadge);
            topBar.Controls.Add(_lblPwmStateBadge);
            this.Controls.Add(topBar);
            y += 62;

            // ================================================================
            // SECTION 1: LIVE TELEMETRY & RESPONSE CURVE DISPLAY
            // ================================================================
            TacticalPanel pnlTelemetry = new TacticalPanel(
                "01 // LIVE TRIGGER TELEMETRY & ROTOR LAG-FILTER OUTPUT",
                "SAMPLING RATE: 500 HZ (2 MS)")
            {
                Location = new Point(margin, y),
                Size = new Size(width, 178)
            };

            int leftColW = width - 195;

            AddTechLabel(pnlTelemetry, "LEFT TRIGGER  [LT // DESCENT]", 14, 36);
            _gaugeLT = new AvionicsBarGauge
            {
                Location = new Point(210, 33),
                Size = new Size(leftColW - 218, 22),
                FillColor = AvionicsTheme.DescentRust,
                LeftText = "RAW: 000/255",
                RightText = "DUTY: 0%"
            };
            pnlTelemetry.Controls.Add(_gaugeLT);

            AddTechLabel(pnlTelemetry, "RIGHT TRIGGER [RT // CLIMB]", 14, 66);
            _gaugeRT = new AvionicsBarGauge
            {
                Location = new Point(210, 63),
                Size = new Size(leftColW - 218, 22),
                FillColor = AvionicsTheme.AmberPrimary,
                LeftText = "RAW: 000/255",
                RightText = "DUTY: 0%"
            };
            pnlTelemetry.Controls.Add(_gaugeRT);

            AddTechLabel(pnlTelemetry, "HELI COLLECTIVE [LAG-FILTER]", 14, 98);
            _gaugeCollective = new CollectiveCenterGauge
            {
                Location = new Point(210, 94),
                Size = new Size(leftColW - 218, 28)
            };
            pnlTelemetry.Controls.Add(_gaugeCollective);

            AddTechLabel(pnlTelemetry, "PWM CARRIER GATE", 14, 136);
            _pnlGateLamp = new Panel
            {
                Location = new Point(210, 134),
                Size = new Size(86, 22),
                BackColor = AvionicsTheme.BgInput
            };
            _lblGateText = new Label
            {
                Text = "IDLE",
                Font = new Font("Consolas", 8.5f, FontStyle.Bold),
                ForeColor = AvionicsTheme.TextDim,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter
            };
            _pnlGateLamp.Controls.Add(_lblGateText);
            pnlTelemetry.Controls.Add(_pnlGateLamp);

            AddMutedLabel(pnlTelemetry,
                "Green strip on LT/RT bars = Post-Curve Duty Cycle. Center gauge simulates Wardogs BHHeli_Core rotor integration.",
                306, 138);

            // Live 2D Response Curve Plot on the right side of Section 1
            _curveCanvas = new ResponseCurveCanvas
            {
                Location = new Point(width - 178, 32),
                Size = new Size(166, 138)
            };
            pnlTelemetry.Controls.Add(_curveCanvas);

            this.Controls.Add(pnlTelemetry);
            y += 186;

            // ================================================================
            // SECTION 2: PWM MODULATOR & RESPONSE CURVE TUNING
            // ================================================================
            TacticalPanel pnlPwm = new TacticalPanel(
                "02 // ANALOG-TO-PWM SIGNAL MODULATOR & CURVE CALIBRATION",
                "TOGGLE IN-GAME: [F8] OR [LB+RB+DPAD UP]")
            {
                Location = new Point(margin, y),
                Size = new Size(width, 212)
            };

            _chkPwmActive = new CheckBox
            {
                Text = "ENABLE HELICOPTER ANALOG-TO-PWM MODULATOR (Pause when driving ground vehicles or infantry)",
                Checked = true,
                Location = new Point(14, 35),
                AutoSize = true,
                Font = new Font("Consolas", 8.75f, FontStyle.Bold),
                ForeColor = AvionicsTheme.PhosphorGreen
            };
            _chkPwmActive.CheckedChanged += (s, e) =>
            {
                _pwmEnabled = _chkPwmActive.Checked;
                if (!_pwmEnabled) ReleaseAllModulatedKeys();
                SyncStatusBadges();
                SaveLocalConfiguration();
            };
            pnlPwm.Controls.Add(_chkPwmActive);

            // Row: Keybindings & Controller Index
            AddTechLabel(pnlPwm, "COLLECTIVE UP KEY (RT):", 14, 66);
            _cmbKeyUp = CreateDarkComboBox(182, 62, 145);
            PopulateKeyBindings(_cmbKeyUp, 0x20); // Default SPACE
            _cmbKeyUp.SelectedIndexChanged += (s, e) =>
            {
                ReleaseAllModulatedKeys();
                _vkCollectiveUp = ((KeyBindingItem)_cmbKeyUp.SelectedItem).VirtualKey;
                SaveLocalConfiguration();
            };
            pnlPwm.Controls.Add(_cmbKeyUp);

            AddTechLabel(pnlPwm, "COLLECTIVE DOWN KEY (LT):", 342, 66);
            _cmbKeyDown = CreateDarkComboBox(518, 62, 145);
            PopulateKeyBindings(_cmbKeyDown, 0xA2); // Default LCTRL
            _cmbKeyDown.SelectedIndexChanged += (s, e) =>
            {
                ReleaseAllModulatedKeys();
                _vkCollectiveDown = ((KeyBindingItem)_cmbKeyDown.SelectedItem).VirtualKey;
                SaveLocalConfiguration();
            };
            pnlPwm.Controls.Add(_cmbKeyDown);

            AddTechLabel(pnlPwm, "PAD:", 676, 66);
            _cmbControllerSlot = CreateDarkComboBox(714, 62, 70);
            _cmbControllerSlot.Items.AddRange(new object[] { "AUTO", "PAD 1", "PAD 2", "PAD 3", "PAD 4" });
            _cmbControllerSlot.SelectedIndex = 0;
            _cmbControllerSlot.SelectedIndexChanged += (s, e) =>
            {
                _preferredControllerSlot = _cmbControllerSlot.SelectedIndex - 1;
                SaveLocalConfiguration();
            };
            pnlPwm.Controls.Add(_cmbControllerSlot);

            // 2x2 Grid of Sliders for PWM Frequency, Expo Curve, Deadzone, Max Authority
            // Slider 1: PWM Carrier Frequency
            AddTechLabel(pnlPwm, "PWM CARRIER FREQ:", 14, 104);
            _trkFreq = CreateSlider(155, 98, 165, 12, 60, 28, 4);
            _lblFreqReadout = AddValueReadout(pnlPwm, "28 Hz (36 ms)", 322, 104);
            _trkFreq.ValueChanged += (s, e) =>
            {
                _pwmFreqHz = _trkFreq.Value;
                int ms = (int)Math.Round(1000.0 / _pwmFreqHz);
                _lblFreqReadout.Text = string.Format("{0} Hz ({1} ms)", _pwmFreqHz, ms);
                SaveLocalConfiguration();
            };
            pnlPwm.Controls.Add(_trkFreq);

            // Slider 2: Response Curve (Expo)
            AddTechLabel(pnlPwm, "RESPONSE EXPO:", 425, 104);
            _trkExpo = CreateSlider(548, 98, 150, 10, 30, 16, 2);
            _lblExpoReadout = AddValueReadout(pnlPwm, "1.60 (SMOOTH)", 700, 104);
            _trkExpo.ValueChanged += (s, e) =>
            {
                _expoCurve = _trkExpo.Value / 10.0f;
                string tag = _expoCurve <= 1.15f ? "LINEAR" : (_expoCurve <= 1.85f ? "SMOOTH" : "FINE HOVER");
                _lblExpoReadout.Text = string.Format(CultureInfo.InvariantCulture, "{0:0.00} ({1})", _expoCurve, tag);
                _curveCanvas.Expo = _expoCurve;
                _curveCanvas.Invalidate();
                SaveLocalConfiguration();
            };
            pnlPwm.Controls.Add(_trkExpo);

            // Slider 3: Inner Deadzone
            AddTechLabel(pnlPwm, "TRIGGER DEADZONE:", 14, 142);
            _trkDzInner = CreateSlider(155, 136, 165, 0, 64, 8, 4);
            _lblDzInnerReadout = AddValueReadout(pnlPwm, "3% (8/255)", 322, 142);
            _trkDzInner.ValueChanged += (s, e) =>
            {
                _deadzoneInner = _trkDzInner.Value;
                int pct = (int)Math.Round((_deadzoneInner / 255.0) * 100.0);
                _lblDzInnerReadout.Text = string.Format("{0}% ({1}/255)", pct, _deadzoneInner);
                float norm = _deadzoneInner / 255.0f;
                _gaugeLT.DeadzoneInnerNorm = norm;
                _gaugeRT.DeadzoneInnerNorm = norm;
                _curveCanvas.DeadzoneInner = norm;
                _gaugeLT.Invalidate();
                _gaugeRT.Invalidate();
                _curveCanvas.Invalidate();
                SaveLocalConfiguration();
            };
            pnlPwm.Controls.Add(_trkDzInner);

            // Slider 4: Max Authority Limit
            AddTechLabel(pnlPwm, "MAX COLLECTIVE:", 425, 142);
            _trkMaxScale = CreateSlider(548, 136, 150, 30, 100, 100, 10);
            _lblMaxScaleReadout = AddValueReadout(pnlPwm, "100% (FULL)", 700, 142);
            _trkMaxScale.ValueChanged += (s, e) =>
            {
                _maxPowerScale = _trkMaxScale.Value / 100.0f;
                _lblMaxScaleReadout.Text = string.Format("{0}% LIMIT", _trkMaxScale.Value);
                _curveCanvas.MaxScale = _maxPowerScale;
                _curveCanvas.Invalidate();
                SaveLocalConfiguration();
            };
            pnlPwm.Controls.Add(_trkMaxScale);

            // Preset Buttons Row
            AddTechLabel(pnlPwm, "FLIGHT PRESETS:", 14, 180);
            Button btnPresetLakota = CreateTacticalButton("UH-72 LAKOTA (GENTLE HOVER)", 155, 174, 195, 26, AvionicsTheme.BgInput, AvionicsTheme.AmberPrimary);
            btnPresetLakota.Click += (s, e) => ApplyTuningPreset(28, 18, 10, 90, "UH-72 Lakota Gentle Hover");
            pnlPwm.Controls.Add(btnPresetLakota);

            Button btnPresetLittlebird = CreateTacticalButton("AH-6 LITTLEBIRD (AGILE)", 358, 174, 195, 26, AvionicsTheme.BgInput, AvionicsTheme.AmberPrimary);
            btnPresetLittlebird.Click += (s, e) => ApplyTuningPreset(32, 15, 6, 100, "AH-6 Littlebird Agile");
            pnlPwm.Controls.Add(btnPresetLittlebird);

            Button btnPresetLinear = CreateTacticalButton("1:1 LINEAR DIRECT", 561, 174, 165, 26, AvionicsTheme.BgInput, AvionicsTheme.TextSecondary);
            btnPresetLinear.Click += (s, e) => ApplyTuningPreset(28, 10, 5, 100, "1:1 Linear Direct");
            pnlPwm.Controls.Add(btnPresetLinear);

            this.Controls.Add(pnlPwm);
            y += 220;

            // ================================================================
            // SECTION 3: UNIVERSAL WARDOGS CONFIG PATCHER (ANY WINDOWS PC)
            // ================================================================
            TacticalPanel pnlConfig = new TacticalPanel(
                "03 // WARDOGS CONFIGURATION PATCHER (GAMEUSERSETTINGS.INI)",
                "AUTO-BACKUP ENABLED")
            {
                Location = new Point(margin, y),
                Size = new Size(width, 134)
            };

            AddTechLabel(pnlConfig, "CONFIG FILE PATH:", 14, 38);
            _txtIniPath = new TextBox
            {
                Location = new Point(140, 35),
                Size = new Size(428, 22),
                BackColor = AvionicsTheme.BgInput,
                ForeColor = AvionicsTheme.TextPrimary,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 8.25f),
                Text = _wardogsIniPath
            };
            _txtIniPath.TextChanged += (s, e) =>
            {
                _wardogsIniPath = _txtIniPath.Text.Trim();
                RefreshIniPathDiagnostics();
            };
            pnlConfig.Controls.Add(_txtIniPath);

            Button btnBrowseIni = CreateTacticalButton("BROWSE...", 574, 34, 88, 24, AvionicsTheme.BgInput, AvionicsTheme.AmberPrimary);
            btnBrowseIni.Click += OnBrowseIniClick;
            pnlConfig.Controls.Add(btnBrowseIni);

            Button btnAutoDetectIni = CreateTacticalButton("AUTO-FIND", 666, 34, 68, 24, AvionicsTheme.BgInput, AvionicsTheme.TextSecondary);
            btnAutoDetectIni.Click += (s, e) =>
            {
                _txtIniPath.Text = AutoDetectWardogsIniPath();
                SaveLocalConfiguration();
                AppendLog("CONFIG // Auto-detected path: " + _wardogsIniPath);
            };
            pnlConfig.Controls.Add(btnAutoDetectIni);

            Button btnOpenFolder = CreateTacticalButton("FOLDER", 738, 34, 52, 24, AvionicsTheme.BgInput, AvionicsTheme.TextSecondary);
            btnOpenFolder.Click += OnOpenIniFolderClick;
            pnlConfig.Controls.Add(btnOpenFolder);

            _lblIniStatus = new Label
            {
                Text = "Checking GameUserSettings.ini...",
                Location = new Point(14, 62),
                Size = new Size(width - 28, 18),
                Font = new Font("Consolas", 8.0f),
                ForeColor = AvionicsTheme.TextSecondary
            };
            pnlConfig.Controls.Add(_lblIniStatus);

            // Patch Action Buttons
            Button btnPatchPwmGuard = CreateTacticalButton(
                "APPLY PATCH A: PWM TRIGGER GUARD [RECOMMENDED]\nSets TriggerMinMultiplier=95% to block 1-2mm 100% spike",
                14, 83, 290, 42, Color.FromArgb(26, 44, 28), AvionicsTheme.PhosphorGreen);
            btnPatchPwmGuard.Click += (s, e) => ApplyGameUserSettingsPatch(patchMode: 1);
            pnlConfig.Controls.Add(btnPatchPwmGuard);

            Button btnPatchHotas = CreateTacticalButton(
                "APPLY PATCH B: NATIVE DIRECTINPUT Z-AXIS HOTAS\nEnables bUseHOTASHelicopters & bCollectiveSelfCentering",
                312, 83, 290, 42, Color.FromArgb(38, 34, 22), AvionicsTheme.AmberPrimary);
            btnPatchHotas.Click += (s, e) => ApplyGameUserSettingsPatch(patchMode: 2);
            pnlConfig.Controls.Add(btnPatchHotas);

            Button btnRestoreBackup = CreateTacticalButton(
                "RESTORE ORIGINAL\nINI BACKUP",
                610, 83, 180, 42, Color.FromArgb(42, 24, 24), AvionicsTheme.DangerRed);
            btnRestoreBackup.Click += (s, e) => RestoreOriginalIniBackup();
            pnlConfig.Controls.Add(btnRestoreBackup);

            this.Controls.Add(pnlConfig);
            y += 142;

            // ================================================================
            // SECTION 4: DIAGNOSTIC TELEMETRY CONSOLE
            // ================================================================
            TacticalPanel pnlLog = new TacticalPanel(
                "04 // SYSTEM DIAGNOSTICS & EVENT LOG",
                "OPEN SOURCE MIT LICENSE")
            {
                Location = new Point(margin, y),
                Size = new Size(width, 114)
            };

            _txtLog = new TextBox
            {
                Location = new Point(10, 32),
                Size = new Size(width - 20, 72),
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor = AvionicsTheme.BgInput,
                ForeColor = AvionicsTheme.TextSecondary,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 8.25f)
            };
            pnlLog.Controls.Add(_txtLog);
            this.Controls.Add(pnlLog);
        }

        // --------------------------------------------------------------------
        // UI Control Factory Helpers
        // --------------------------------------------------------------------
        private static Label AddTechLabel(Control parent, string text, int x, int y)
        {
            Label lbl = new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                Font = new Font("Consolas", 8.5f, FontStyle.Bold),
                ForeColor = AvionicsTheme.TextSecondary
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private static Label AddValueReadout(Control parent, string text, int x, int y)
        {
            Label lbl = new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                Font = new Font("Consolas", 8.5f, FontStyle.Bold),
                ForeColor = AvionicsTheme.AmberBright
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private static Label AddMutedLabel(Control parent, string text, int x, int y)
        {
            Label lbl = new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                Font = new Font("Segoe UI", 8.0f, FontStyle.Regular),
                ForeColor = AvionicsTheme.TextDim
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private static ComboBox CreateDarkComboBox(int x, int y, int w)
        {
            return new ComboBox
            {
                Location = new Point(x, y),
                Size = new Size(w, 24),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = AvionicsTheme.BgInput,
                ForeColor = AvionicsTheme.TextPrimary,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Consolas", 8.5f)
            };
        }

        private static TrackBar CreateSlider(int x, int y, int w, int min, int max, int val, int tick)
        {
            return new TrackBar
            {
                Location = new Point(x, y),
                Size = new Size(w, 26),
                Minimum = min,
                Maximum = max,
                Value = val,
                TickFrequency = tick,
                AutoSize = false,
                BackColor = AvionicsTheme.BgPanel
            };
        }

        private static Button CreateTacticalButton(string text, int x, int y, int w, int h, Color backColor, Color borderColor)
        {
            Button btn = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(w, h),
                BackColor = backColor,
                ForeColor = AvionicsTheme.TextPrimary,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Consolas", 8.0f, FontStyle.Bold),
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleCenter
            };
            btn.FlatAppearance.BorderColor = borderColor;
            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(38, 44, 38);
            return btn;
        }

        private static void PopulateKeyBindings(ComboBox cmb, ushort defaultVk)
        {
            KeyBindingItem[] items = new KeyBindingItem[]
            {
                new KeyBindingItem("SPACEBAR (0x20)", 0x20),
                new KeyBindingItem("LEFT CTRL (0xA2)", 0xA2),
                new KeyBindingItem("LEFT SHIFT (0xA0)", 0xA0),
                new KeyBindingItem("KEY [W] (0x57)", 0x57),
                new KeyBindingItem("KEY [S] (0x53)", 0x53),
                new KeyBindingItem("KEY [C] (0x43)", 0x43),
                new KeyBindingItem("ARROW UP (0x26)", 0x26),
                new KeyBindingItem("ARROW DOWN (0x28)", 0x28),
                new KeyBindingItem("KEY [E] (0x45)", 0x45),
                new KeyBindingItem("KEY [Q] (0x51)", 0x51),
                new KeyBindingItem("KEY [R] (0x52)", 0x52),
                new KeyBindingItem("KEY [F] (0x46)", 0x46)
            };

            int selectedIdx = 0;
            for (int i = 0; i < items.Length; i++)
            {
                cmb.Items.Add(items[i]);
                if (items[i].VirtualKey == defaultVk)
                    selectedIdx = i;
            }
            cmb.SelectedIndex = selectedIdx;
        }

        private void ApplyTuningPreset(int freq, int expoTenths, int dzInner, int maxPct, string name)
        {
            _trkFreq.Value = freq;
            _trkExpo.Value = expoTenths;
            _trkDzInner.Value = dzInner;
            _trkMaxScale.Value = maxPct;
            AppendLog("PRESET LOADED // Applied flight profile: " + name);
        }

        // --------------------------------------------------------------------
        // High-Frequency 500 Hz XInput Polling & PWM Generation Loop
        // --------------------------------------------------------------------
        private bool PollGamepadState(out XINPUT_STATE state, out int resolvedSlot)
        {
            state = default(XINPUT_STATE);
            resolvedSlot = -1;

            // If user locked a specific controller slot (0..3)
            int preferred = _preferredControllerSlot;
            if (preferred >= 0 && preferred < 4)
            {
                if (TryXInputGetState((uint)preferred, out state) == 0)
                {
                    resolvedSlot = preferred;
                    return true;
                }
                return false;
            }

            // If a controller was already active, poll it first to avoid unnecessary calls
            int current = _activeControllerIndex;
            if (current >= 0 && current < 4)
            {
                if (TryXInputGetState((uint)current, out state) == 0)
                {
                    resolvedSlot = current;
                    return true;
                }
            }

            // Scan slots 0..3
            for (uint i = 0; i < 4; i++)
            {
                if (TryXInputGetState(i, out state) == 0)
                {
                    resolvedSlot = (int)i;
                    return true;
                }
            }
            return false;
        }

        private static uint TryXInputGetState(uint index, out XINPUT_STATE state)
        {
            try { return XInputGetState_14(index, out state); }
            catch
            {
                try { return XInputGetState_13(index, out state); }
                catch
                {
                    try { return XInputGetState_910(index, out state); }
                    catch
                    {
                        state = default(XINPUT_STATE);
                        return 1167; // ERROR_DEVICE_NOT_CONNECTED
                    }
                }
            }
        }

        private float ComputeCurvedDutyCycle(byte rawTrigger)
        {
            int inner = _deadzoneInner;
            int outer = _deadzoneOuter;
            if (rawTrigger <= inner) return 0f;
            if (rawTrigger >= outer) return _maxPowerScale;

            float normalized = (float)(rawTrigger - inner) / Math.Max(1f, (float)(outer - inner));
            float curved = (float)Math.Pow(normalized, _expoCurve) * _maxPowerScale;
            return Math.Max(0f, Math.Min(1f, curved));
        }

        private void PwmSamplingLoop()
        {
            Stopwatch clock = Stopwatch.StartNew();
            bool prevF8 = false;
            bool prevPadCombo = false;
            double prevTimeSec = clock.Elapsed.TotalSeconds;

            while (_running)
            {
                double nowSec = clock.Elapsed.TotalSeconds;
                double dt = Math.Max(0.0005, nowSec - prevTimeSec);
                prevTimeSec = nowSec;

                // 1. Check Global Keyboard Toggle [F8]
                bool f8Pressed = (GetAsyncKeyState(0x77) & 0x8000) != 0;
                if (f8Pressed && !prevF8)
                {
                    TogglePwmModulatorState("Keyboard Hotkey [F8]");
                }
                prevF8 = f8Pressed;

                // 2. Poll XInput Controller
                XINPUT_STATE padState;
                int slot;
                if (PollGamepadState(out padState, out slot))
                {
                    _activeControllerIndex = slot;
                    byte lt = padState.Gamepad.bLeftTrigger;
                    byte rt = padState.Gamepad.bRightTrigger;
                    _rawLT = lt;
                    _rawRT = rt;

                    // Check Controller Chord Toggle: [LB + RB + D-Pad UP]
                    ushort buttons = padState.Gamepad.wButtons;
                    bool chordPressed =
                        ((buttons & XINPUT_GAMEPAD_LEFT_SHOULDER) != 0) &&
                        ((buttons & XINPUT_GAMEPAD_RIGHT_SHOULDER) != 0) &&
                        ((buttons & XINPUT_GAMEPAD_DPAD_UP) != 0);

                    if (chordPressed && !prevPadCombo)
                    {
                        TogglePwmModulatorState("Gamepad Chord [LB + RB + D-Pad UP]");
                    }
                    prevPadCombo = chordPressed;

                    // Compute individual trigger duty cycles
                    float dutyUp = ComputeCurvedDutyCycle(rt);
                    float dutyDown = ComputeCurvedDutyCycle(lt);

                    // If both triggers are pulled simultaneously, compute net differential collective
                    if (dutyUp > 0f && dutyDown > 0f)
                    {
                        if (dutyUp >= dutyDown)
                        {
                            dutyUp -= dutyDown;
                            dutyDown = 0f;
                        }
                        else
                        {
                            dutyDown -= dutyUp;
                            dutyUp = 0f;
                        }
                    }

                    _dutyUp = dutyUp;
                    _dutyDown = dutyDown;

                    // Calculate instantaneous phase within the PWM carrier period [0.0 .. 1.0)
                    double periodSec = 1.0 / Math.Max(10, _pwmFreqHz);
                    double phase = (nowSec % periodSec) / periodSec;

                    bool pulseUp = _pwmEnabled && (dutyUp > 0.01f) && (dutyUp >= 0.99f || phase < dutyUp);
                    bool pulseDown = _pwmEnabled && (dutyDown > 0.01f) && (dutyDown >= 0.99f || phase < dutyDown);

                    _pulseStateUp = pulseUp;
                    _pulseStateDown = pulseDown;

                    EmitHardwareKeyScancode(_vkCollectiveUp, pulseUp, ref _keyUpPressedByUs);
                    EmitHardwareKeyScancode(_vkCollectiveDown, pulseDown, ref _keyDownPressedByUs);

                    // Simulate Wardogs BHHeli_Core LagFilter rotor integration (~120ms time constant)
                    float instantCommand = (pulseUp ? 1.0f : 0.0f) - (pulseDown ? 1.0f : 0.0f);
                    float alpha = (float)(1.0 - Math.Exp(-dt / 0.12));
                    _simulatedCollective += (instantCommand - _simulatedCollective) * alpha;
                }
                else
                {
                    _activeControllerIndex = -1;
                    _rawLT = 0;
                    _rawRT = 0;
                    _dutyUp = 0f;
                    _dutyDown = 0f;
                    _pulseStateUp = false;
                    _pulseStateDown = false;
                    ReleaseAllModulatedKeys();
                }

                Thread.Sleep(2); // ~500 Hz sampling rate
            }

            ReleaseAllModulatedKeys();
        }

        private void TogglePwmModulatorState(string source)
        {
            _pwmEnabled = !_pwmEnabled;
            if (!_pwmEnabled)
                ReleaseAllModulatedKeys();

            try { Console.Beep(_pwmEnabled ? 920 : 440, 80); } catch { }
            SyncStatusBadges();
            AppendLog(string.Format("MODULATOR // {0} via {1}.", _pwmEnabled ? "ARMED (ACTIVE)" : "BYPASSED (PAUSED)", source));
        }

        private static void EmitHardwareKeyScancode(ushort virtualKey, bool keyDown, ref bool isCurrentlyDown)
        {
            if (keyDown == isCurrentlyDown)
                return;

            ushort scancode = (ushort)MapVirtualKey(virtualKey, 0);
            uint flags = KEYEVENTF_SCANCODE;
            if (!keyDown)
                flags |= KEYEVENTF_KEYUP;

            // Arrow keys and Right Ctrl require the extended scancode prefix
            if (virtualKey == 0x26 || virtualKey == 0x28 || virtualKey == 0x25 || virtualKey == 0x27 || virtualKey == 0xA3)
                flags |= KEYEVENTF_EXTENDEDKEY;

            INPUT[] input = new INPUT[1];
            input[0].type = INPUT_KEYBOARD;
            input[0].u.ki.wVk = 0;
            input[0].u.ki.wScan = scancode;
            input[0].u.ki.dwFlags = flags;
            input[0].u.ki.time = 0;
            input[0].u.ki.dwExtraInfo = IntPtr.Zero;

            SendInput(1, input, Marshal.SizeOf(typeof(INPUT)));
            isCurrentlyDown = keyDown;
        }

        private void ReleaseAllModulatedKeys()
        {
            EmitHardwareKeyScancode(_vkCollectiveUp, false, ref _keyUpPressedByUs);
            EmitHardwareKeyScancode(_vkCollectiveDown, false, ref _keyDownPressedByUs);
        }

        // --------------------------------------------------------------------
        // UI Refresh Tick (~33 FPS)
        // --------------------------------------------------------------------
        private void OnUiRefreshTick(object sender, EventArgs e)
        {
            int slot = _activeControllerIndex;
            if (slot >= 0)
            {
                _lblGamepadBadge.Text = string.Format("[XINPUT PAD #{0}: ONLINE]", slot + 1);
                _lblGamepadBadge.ForeColor = AvionicsTheme.PhosphorGreen;
            }
            else
            {
                _lblGamepadBadge.Text = "[XINPUT: STANDBY]";
                _lblGamepadBadge.ForeColor = AvionicsTheme.AmberPrimary;
            }

            int lt = _rawLT;
            int rt = _rawRT;
            float dutyDown = _dutyDown;
            float dutyUp = _dutyUp;

            _gaugeLT.ValueNormalized = lt / 255.0f;
            _gaugeLT.SecondaryNormalized = dutyDown;
            _gaugeLT.LeftText = string.Format("RAW: {0:000}/255", lt);
            _gaugeLT.RightText = string.Format("DUTY: {0}%", (int)Math.Round(dutyDown * 100f));
            _gaugeLT.Invalidate();

            _gaugeRT.ValueNormalized = rt / 255.0f;
            _gaugeRT.SecondaryNormalized = dutyUp;
            _gaugeRT.LeftText = string.Format("RAW: {0:000}/255", rt);
            _gaugeRT.RightText = string.Format("DUTY: {0}%", (int)Math.Round(dutyUp * 100f));
            _gaugeRT.Invalidate();

            _gaugeCollective.CollectiveValue = _simulatedCollective;
            _gaugeCollective.Invalidate();

            // Update live operating dot on the 2D Response Curve Canvas
            if (rt >= lt)
            {
                _curveCanvas.LiveInputX = rt / 255.0f;
                _curveCanvas.LiveOutputY = dutyUp;
            }
            else
            {
                _curveCanvas.LiveInputX = lt / 255.0f;
                _curveCanvas.LiveOutputY = dutyDown;
            }
            _curveCanvas.Invalidate();

            // Update PWM Gate Indicator Lamp
            if (_pulseStateUp)
            {
                _pnlGateLamp.BackColor = AvionicsTheme.PhosphorGreen;
                _lblGateText.ForeColor = AvionicsTheme.BgChassis;
                _lblGateText.Text = "CLIMB HI";
            }
            else if (_pulseStateDown)
            {
                _pnlGateLamp.BackColor = AvionicsTheme.DescentRust;
                _lblGateText.ForeColor = AvionicsTheme.BgChassis;
                _lblGateText.Text = "DESC HI";
            }
            else
            {
                _pnlGateLamp.BackColor = AvionicsTheme.BgInput;
                _lblGateText.ForeColor = AvionicsTheme.TextDim;
                _lblGateText.Text = _pwmEnabled ? "GATE LO" : "BYPASSED";
            }
        }

        private void SyncStatusBadges()
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action(SyncStatusBadges));
                return;
            }
            _chkPwmActive.Checked = _pwmEnabled;
            if (_pwmEnabled)
            {
                _lblPwmStateBadge.Text = "[MODULATOR: ARMED]";
                _lblPwmStateBadge.ForeColor = AvionicsTheme.PhosphorGreen;
                _chkPwmActive.ForeColor = AvionicsTheme.PhosphorGreen;
            }
            else
            {
                _lblPwmStateBadge.Text = "[MODULATOR: PAUSED]";
                _lblPwmStateBadge.ForeColor = AvionicsTheme.DescentRust;
                _chkPwmActive.ForeColor = AvionicsTheme.AmberPrimary;
            }
        }

        private void AppendLog(string message)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action<string>(AppendLog), message);
                return;
            }
            string timestamped = string.Format("[{0:HH:mm:ss}] {1}{2}", DateTime.Now, message, Environment.NewLine);
            _txtLog.AppendText(timestamped);
        }

        // --------------------------------------------------------------------
        // Universal Diff-Safe Wardogs GameUserSettings.ini Parser & Patcher
        // --------------------------------------------------------------------
        private string GetBackupIniPath()
        {
            return _wardogsIniPath + ".heli_backup";
        }

        private void RefreshIniPathDiagnostics()
        {
            if (File.Exists(_wardogsIniPath))
            {
                string backupStatus = File.Exists(GetBackupIniPath()) ? "Backup present" : "No backup yet (will create on patch)";
                _lblIniStatus.Text = string.Format("STATUS: FOUND // {0}", backupStatus);
                _lblIniStatus.ForeColor = AvionicsTheme.PhosphorGreen;
            }
            else
            {
                _lblIniStatus.Text = "STATUS: FILE NOT FOUND AT PATH // Use 'BROWSE...' if Wardogs is installed on another drive/profile.";
                _lblIniStatus.ForeColor = AvionicsTheme.DescentRust;
            }
        }

        private void OnBrowseIniClick(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Select Wardogs GameUserSettings.ini";
                dlg.Filter = "Unreal Config (GameUserSettings.ini)|GameUserSettings.ini|INI Files (*.ini)|*.ini|All Files (*.*)|*.*";
                string dir = Path.GetDirectoryName(_wardogsIniPath);
                if (!string.IsNullOrEmpty(dir) && Directory.Exists(dir))
                    dlg.InitialDirectory = dir;

                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    _txtIniPath.Text = dlg.FileName;
                    SaveLocalConfiguration();
                    AppendLog("CONFIG // Selected GameUserSettings.ini: " + _wardogsIniPath);
                }
            }
        }

        private void OnOpenIniFolderClick(object sender, EventArgs e)
        {
            try
            {
                string dir = Path.GetDirectoryName(_wardogsIniPath);
                if (!string.IsNullOrEmpty(dir) && Directory.Exists(dir))
                    Process.Start("explorer.exe", dir);
                else
                    MessageBox.Show(this, "Directory does not exist:\n" + dir, "Folder Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                AppendLog("ERROR // Could not open folder: " + ex.Message);
            }
        }

        /// <summary>
        /// Safely updates or inserts key-value pairs inside a specific INI section.
        /// Works reliably even on fresh Wardogs installations where Diff=true omits unchanged keys.
        /// </summary>
        private static string UpsertIniSectionKeys(string iniContent, string sectionHeader, Dictionary<string, string> keyValues)
        {
            string normalized = iniContent.Replace("\r\n", "\n");
            string[] lines = normalized.Split('\n');
            List<string> output = new List<string>(lines.Length + keyValues.Count + 4);

            bool inTargetSection = false;
            bool sectionFound = false;
            HashSet<string> writtenKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string trimmed = line.Trim();

                if (trimmed.StartsWith("[") && trimmed.EndsWith("]"))
                {
                    // Before leaving the target section, insert any keys that were missing
                    if (inTargetSection)
                    {
                        foreach (KeyValuePair<string, string> kvp in keyValues)
                        {
                            if (!writtenKeys.Contains(kvp.Key))
                            {
                                output.Add(kvp.Key + "=" + kvp.Value);
                                writtenKeys.Add(kvp.Key);
                            }
                        }
                    }

                    inTargetSection = string.Equals(trimmed, sectionHeader, StringComparison.OrdinalIgnoreCase);
                    if (inTargetSection)
                        sectionFound = true;

                    output.Add(line);
                    continue;
                }

                if (inTargetSection && !trimmed.StartsWith(";") && trimmed.Contains("="))
                {
                    int eqIdx = line.IndexOf('=');
                    string k = line.Substring(0, eqIdx).Trim();
                    string replacementVal;
                    if (keyValues.TryGetValue(k, out replacementVal))
                    {
                        output.Add(k + "=" + replacementVal);
                        writtenKeys.Add(k);
                        continue;
                    }
                }

                output.Add(line);
            }

            // If file ended while still inside the target section, flush remaining keys
            if (inTargetSection)
            {
                foreach (KeyValuePair<string, string> kvp in keyValues)
                {
                    if (!writtenKeys.Contains(kvp.Key))
                    {
                        output.Add(kvp.Key + "=" + kvp.Value);
                        writtenKeys.Add(kvp.Key);
                    }
                }
            }

            // If the section did not exist at all, append it cleanly
            if (!sectionFound)
            {
                if (output.Count > 0 && !string.IsNullOrEmpty(output[output.Count - 1]))
                    output.Add("");
                output.Add(sectionHeader);
                foreach (KeyValuePair<string, string> kvp in keyValues)
                    output.Add(kvp.Key + "=" + kvp.Value);
            }

            return string.Join("\r\n", output.ToArray());
        }

        private void ApplyGameUserSettingsPatch(int patchMode)
        {
            try
            {
                if (!File.Exists(_wardogsIniPath))
                {
                    MessageBox.Show(this,
                        "GameUserSettings.ini was not found at:\n" + _wardogsIniPath +
                        "\n\nPlease launch Wardogs at least once or click 'BROWSE...' to locate your config file.",
                        "Config File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string backupPath = GetBackupIniPath();
                if (!File.Exists(backupPath))
                {
                    File.Copy(_wardogsIniPath, backupPath, false);
                    AppendLog("BACKUP // Created clean backup: " + backupPath);
                }

                FileAttributes attrs = File.GetAttributes(_wardogsIniPath);
                if ((attrs & FileAttributes.ReadOnly) != 0)
                    File.SetAttributes(_wardogsIniPath, attrs & ~FileAttributes.ReadOnly);

                string content = File.ReadAllText(_wardogsIniPath, Encoding.UTF8);

                if (patchMode == 1)
                {
                    // PATCH A: PWM Trigger Guard
                    // Sets TriggerMinMultiplier to 95.0 so Wardogs ignores the 0-95% binary trigger threshold,
                    // allowing our 500 Hz PWM modulator to drive proportional collective across 0-95% travel.
                    Dictionary<string, string> settings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                    {
                        { "TriggersPreset", "None" },
                        { "LeftTriggerMinMultiplier", "95.000000" },
                        { "LeftTriggerMaxMultiplier", "100.000000" },
                        { "RightTriggerMinMultiplier", "95.000000" },
                        { "RightTriggerMaxMultiplier", "100.000000" },
                        { "bUseHOTASHelicopters", "False" }
                    };

                    content = UpsertIniSectionKeys(content, "[/Script/WDGame.WDUserSettings]", settings);
                    if (content.IndexOf("[None.WDUserSettings]", StringComparison.OrdinalIgnoreCase) >= 0)
                        content = UpsertIniSectionKeys(content, "[None.WDUserSettings]", settings);

                    File.WriteAllText(_wardogsIniPath, content, Encoding.UTF8);
                    RefreshIniPathDiagnostics();
                    AppendLog("PATCH A APPLIED // TriggerMinMultiplier=95.0 set in GameUserSettings.ini.");

                    MessageBox.Show(this,
                        "PATCH A (PWM Trigger Guard) applied successfully!\n\n" +
                        "What was updated in GameUserSettings.ini:\n" +
                        "  • LeftTriggerMinMultiplier = 95.000000\n" +
                        "  • RightTriggerMinMultiplier = 95.000000\n" +
                        "  • bUseHOTASHelicopters = False\n\n" +
                        "How it works:\n" +
                        "  • Wardogs will no longer fire 100% binary collective when you press the trigger 1-2mm.\n" +
                        "  • This utility reads your physical trigger across 0-255 and drives proportional PWM collective from 0% to 95%.\n" +
                        "  • Pressing past 95% engages full 100% native trigger lock.",
                        "Patch A Applied", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (patchMode == 2)
                {
                    // PATCH B: Native DirectInput Z-Axis HOTAS Self-Centering Mode
                    Dictionary<string, string> settings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                    {
                        { "bUseHOTASHelicopters", "True" },
                        { "bCollectiveSelfCentering", "True" },
                        { "LeftTriggerMinMultiplier", "0.000000" },
                        { "RightTriggerMinMultiplier", "0.000000" }
                    };

                    content = UpsertIniSectionKeys(content, "[/Script/WDGame.WDUserSettings]", settings);
                    if (content.IndexOf("[None.WDUserSettings]", StringComparison.OrdinalIgnoreCase) >= 0)
                        content = UpsertIniSectionKeys(content, "[None.WDUserSettings]", settings);

                    File.WriteAllText(_wardogsIniPath, content, Encoding.UTF8);
                    RefreshIniPathDiagnostics();
                    AppendLog("PATCH B APPLIED // bUseHOTASHelicopters=True & bCollectiveSelfCentering=True set.");

                    MessageBox.Show(this,
                        "PATCH B (Native DirectInput Z-Axis HOTAS) applied successfully!\n\n" +
                        "What was updated in GameUserSettings.ini:\n" +
                        "  • bUseHOTASHelicopters = True\n" +
                        "  • bCollectiveSelfCentering = True\n" +
                        "  • Left/RightTriggerMinMultiplier = 0.000000\n\n" +
                        "Note: If using Patch B, pause the PWM Modulator [F8] so only DirectInput Axis 2 is used.",
                        "Patch B Applied", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                AppendLog("ERROR // Failed to patch GameUserSettings.ini: " + ex.Message);
                MessageBox.Show(this, "Failed to update GameUserSettings.ini:\n" + ex.Message,
                    "Patch Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RestoreOriginalIniBackup()
        {
            try
            {
                string backupPath = GetBackupIniPath();
                if (!File.Exists(backupPath))
                {
                    MessageBox.Show(this,
                        "No backup file (.heli_backup) exists yet.\nA backup is automatically created the first time you apply Patch A or Patch B.",
                        "No Backup Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (File.Exists(_wardogsIniPath))
                {
                    FileAttributes attrs = File.GetAttributes(_wardogsIniPath);
                    if ((attrs & FileAttributes.ReadOnly) != 0)
                        File.SetAttributes(_wardogsIniPath, attrs & ~FileAttributes.ReadOnly);
                }

                File.Copy(backupPath, _wardogsIniPath, true);
                RefreshIniPathDiagnostics();
                AppendLog("RESTORE // Original GameUserSettings.ini restored from backup.");
                MessageBox.Show(this, "Original GameUserSettings.ini has been restored from backup.",
                    "Backup Restored", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                AppendLog("ERROR // Restore failed: " + ex.Message);
                MessageBox.Show(this, "Failed to restore backup:\n" + ex.Message,
                    "Restore Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // --------------------------------------------------------------------
        // Local Persistent Settings (WardogsTriggerFix.cfg)
        // --------------------------------------------------------------------
        private void SaveLocalConfiguration()
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("# Wardogs Helicopter Analog Trigger Fix - Local Settings");
                sb.AppendLine("PwmFreqHz=" + _pwmFreqHz.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("ExpoTenths=" + _trkExpo.Value.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("DeadzoneInner=" + _deadzoneInner.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("MaxScalePct=" + _trkMaxScale.Value.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("VkCollectiveUp=" + ((int)_vkCollectiveUp).ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("VkCollectiveDown=" + ((int)_vkCollectiveDown).ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("ControllerSlot=" + _preferredControllerSlot.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("WardogsIniPath=" + (_wardogsIniPath ?? ""));
                File.WriteAllText(_localConfigPath, sb.ToString(), Encoding.UTF8);
            }
            catch { }
        }

        private void LoadLocalConfiguration()
        {
            try
            {
                if (!File.Exists(_localConfigPath))
                    return;

                string[] lines = File.ReadAllLines(_localConfigPath, Encoding.UTF8);
                foreach (string rawLine in lines)
                {
                    string line = rawLine.Trim();
                    if (string.IsNullOrEmpty(line) || line.StartsWith("#") || !line.Contains("="))
                        continue;

                    int idx = line.IndexOf('=');
                    string key = line.Substring(0, idx).Trim();
                    string val = line.Substring(idx + 1).Trim();

                    int parsedInt;
                    if (key.Equals("PwmFreqHz", StringComparison.OrdinalIgnoreCase) && int.TryParse(val, out parsedInt))
                        _trkFreq.Value = Math.Max(_trkFreq.Minimum, Math.Min(_trkFreq.Maximum, parsedInt));
                    else if (key.Equals("ExpoTenths", StringComparison.OrdinalIgnoreCase) && int.TryParse(val, out parsedInt))
                        _trkExpo.Value = Math.Max(_trkExpo.Minimum, Math.Min(_trkExpo.Maximum, parsedInt));
                    else if (key.Equals("DeadzoneInner", StringComparison.OrdinalIgnoreCase) && int.TryParse(val, out parsedInt))
                        _trkDzInner.Value = Math.Max(_trkDzInner.Minimum, Math.Min(_trkDzInner.Maximum, parsedInt));
                    else if (key.Equals("MaxScalePct", StringComparison.OrdinalIgnoreCase) && int.TryParse(val, out parsedInt))
                        _trkMaxScale.Value = Math.Max(_trkMaxScale.Minimum, Math.Min(_trkMaxScale.Maximum, parsedInt));
                    else if (key.Equals("VkCollectiveUp", StringComparison.OrdinalIgnoreCase) && int.TryParse(val, out parsedInt))
                        SelectComboByVirtualKey(_cmbKeyUp, (ushort)parsedInt);
                    else if (key.Equals("VkCollectiveDown", StringComparison.OrdinalIgnoreCase) && int.TryParse(val, out parsedInt))
                        SelectComboByVirtualKey(_cmbKeyDown, (ushort)parsedInt);
                    else if (key.Equals("ControllerSlot", StringComparison.OrdinalIgnoreCase) && int.TryParse(val, out parsedInt))
                        _cmbControllerSlot.SelectedIndex = Math.Max(0, Math.Min(4, parsedInt + 1));
                    else if (key.Equals("WardogsIniPath", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(val))
                    {
                        if (File.Exists(val))
                            _txtIniPath.Text = val;
                    }
                }
            }
            catch { }
        }

        private static void SelectComboByVirtualKey(ComboBox cmb, ushort vk)
        {
            for (int i = 0; i < cmb.Items.Count; i++)
            {
                KeyBindingItem item = (KeyBindingItem)cmb.Items[i];
                if (item.VirtualKey == vk)
                {
                    cmb.SelectedIndex = i;
                    return;
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _running = false;
            if (_uiTimer != null) _uiTimer.Stop();
            ReleaseAllModulatedKeys();
            timeEndPeriod(1);
            SaveLocalConfiguration();
            base.OnFormClosing(e);
        }

        [STAThread]
        public static void Main()
        {
            try { SetProcessDPIAware(); } catch { }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
