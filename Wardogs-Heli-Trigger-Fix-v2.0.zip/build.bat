@echo off
title WARDOGS Helicopter Trigger Fix - Build from Source
cd /d "%~dp0"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"

if not exist "%CSC%" (
    echo [ERROR] Microsoft .NET Framework v4.0 compiler ^(csc.exe^) was not found.
    pause
    exit /b 1
)

echo ============================================================================
echo Building Wardogs_Heli_Trigger_Fix.exe from src\WardogsHeliTriggerFix.cs ...
echo ============================================================================
"%CSC%" /target:winexe /optimize+ /out:"%~dp0Wardogs_Heli_Trigger_Fix.exe" /r:System.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll "%~dp0src\WardogsHeliTriggerFix.cs"

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Compilation failed.
    pause
    exit /b 1
)

echo.
echo [SUCCESS] Built Wardogs_Heli_Trigger_Fix.exe successfully!
pause
